# Ground-truth creation: living publication package

**Publication-ready local draft; not externally published.** Updated October 18, 2026. Human review remains in progress. The package preserves previous articles and diagrams and does not modify frozen corpus, annotation, benchmark or application records.

Start with [the complete article](article.md). It explains the product problem, taxonomy semantics, corpus cleanup, two independent LLM-powered Codex readers, deterministic checks, real proposal disagreements, human review and the later evaluation plan. No extra external model call or separate judge is claimed.

## Files

| File | Purpose |
|---|---|
| [article.md](article.md) | Main publishable living narrative, with current/planned boundaries. |
| [statistics.json](statistics.json) | Dated aggregate snapshot, source hashes, frozen experiment facts and separate live human-review counts. |
| [worked-example.json](worked-example.json) | Exact public-repository ID/commit/source bindings and observed canonical proposal sets; no human outcome invented. |
| [figures/](figures/) | Three new illustrated figures in the established paper/ink/marker style. |
| [figures/prompts.json](figures/prompts.json) | Complete built-in image-generation prompts, source references and export metadata. |
| [editorial-and-claim-review.md](editorial-and-claim-review.md) | Claims, caveats, refinement passes and QA limits. |
| [verification.json](verification.json) | Link, exact-source, numerical and actual-export checks. |
| [scripts/refresh_statistics.py](scripts/refresh_statistics.py) | Read-only local aggregate updater; refuses to overwrite snapshots or write outside this package. |

## Update this document safely

1. Capture a **new** snapshot, retaining `statistics.json` as the original article baseline. From the repository root:

   ```sh
   python3 ai-system-design/ground-truth-creation/scripts/refresh_statistics.py \
     --output ai-system-design/ground-truth-creation/history/statistics-YYYY-MM-DD-N.json
   ```

   The script reads the existing frozen release/pilot and opens SQLite in read-only mode. It exports aggregate counts and hashes only. No credentials, actor identity, purpose text or individual human label decisions are exported. It makes no network or model requests. The private evidence files must exist on the author's machine; an external reader can inspect the public methodology and retained snapshot without possessing them.

2. Compare live corpus-review count, **pilot intersection**, initial-queue intersection, status and pilot-binding count. Do not copy the frozen sidecar's historical `human_confirmed: 0` into a live-progress claim. Multiple owner-scoped records are not automatically independent expert consensus or a globally deduplicated gold set.
3. Update the article's date, status table and “Where we stand” section together. Record the old/new counts and relevant policy/source changes in a dated note. User-facing calendar dates follow the supplied America/New_York client date; the machine capture timestamp is separate.
4. Preserve immutable sources, original proposals and previous human revisions. New taxonomy definitions require a new version and explicit re-review/rebinding where relevant. Never silently replace evidence under a published hash.
5. Keep **curation peer audits**, **independent annotation**, **human adjudication**, **functional UI tests** and **classifier/RAG evaluation** separate. They measure different things. Run a link/image/claim audit and inspect the actual exports after material edits.
6. Before reporting precision/recall/F1 or a confidence threshold, freeze the reference semantics: reviewed positives, reviewed negatives, unknowns, completeness and split boundaries. Before generalizing a correction rate, separate targeted and random sample outcomes with denominators and uncertainty.

No publisher, platform or hosting update is authorized or performed by this artifact task. Public READMEs can be quoted only briefly here; the article uses a short excerpt plus paraphrase and pinned-source links. Retained full source snapshots are not copied into this publication folder.

## Reuse the illustration/writing approach

This package applies [engaging-technical-writing](../../skills/engaging-technical-writing/SKILL.md) and [illustrated-explainers](../../skills/illustrated-explainers/SKILL.md), with the built-in imagegen skill/tool. Four built-in image-generation calls created three figures and a corrected third figure. These illustration calls are separate from the annotation experiment's zero-extra-provider-request claim; no app API key, annotation budget reset or direct provider API runner was used.

Use the prompts with a real style-reference image. Preserve authority boundaries: robots propose; deterministic software checks integrity; a person adjudicates; future evaluation stays visibly planned. Semantic objects—not architecture boxes—carry the explanation. A current review-count change should generally update prose/statistics rather than force a new illustration.

## Short publication description

An AI repository organizer needs a trustworthy answer key before its accuracy means anything. This case study follows six hundred public repositories into a thirty-repository double-annotation pilot, showing what two independent AI readers agree on, where they differ, what evidence checks can prove, and why human review still owns the final decision.
