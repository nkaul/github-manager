# Our RAG approach — illustration for review

**October 20, 2026 · Review proposal. This figure and its new RAG explanation have not been added to [Inside the GitHub Manager AI Pipeline](../../github-manager-ai-pipeline.md).**

![Three stages of GitHub Manager's fixed sparse RAG classification: Retrieval searches approved label definitions using repository evidence; Augment assembles compact evidence, RAKE phrases and candidate definitions with instructions and schema; Generate returns structured canonical selections for validation and human review. Saved application-state documents and the separate taxonomy-discovery path sit outside the main flow.](rag-approach-review-v3.png)

*Proposed caption: GitHub Manager uses a fixed retrieve-then-generate path for model-assisted classification. Retrieval finds possible canonical labels; augmentation builds the bounded request; generation produces structured selections for validation and review. Stored profiles, taxonomy, decisions and analysis receipts provide application memory; they are not a conversational or vector-memory retriever. Taxonomy discovery proposes vocabulary separately. Project/Topic/Tag cards are schematic kind markers, and the output sheet highlights selected fields rather than displaying a complete schema or a new model result. Evidence-ID checks do not establish semantic support for every selection.*

## The name I recommend

**Fixed, single-pass sparse retrieval-augmented classification, with durable application memory.**

In plain language: we first look up possible existing labels, put their definitions beside a small amount of repository evidence, and ask the model which labels the evidence supports. “Sparse” means word-based retrieval here. The retrieved knowledge is the label vocabulary, rather than a collection of other repositories or README chunks.

This description is an interpretation of the current code, not a new component or a claim of measured performance. Its control flow resembles **simple / two-step RAG**: retrieval precedes generation. LangChain distinguishes that fixed pattern from agentic retrieval, where the model decides when and how to search. Our application performs structured classification rather than an open-ended question-answering task. [LangChain retrieval architectures](https://docs.langchain.com/oss/python/deepagents/retrieval).

## How the common RAG types compare

These names describe different design choices, so they are not a single, mutually exclusive checklist. **Control flow** asks who decides when to retrieve. **Search strategy** asks how matching works. **Memory** asks what is retained and reused.

| Common name | Plain-language meaning | Where GitHub Manager fits |
|---|---|---|
| Simple / two-step RAG | Retrieve relevant knowledge, assemble context, then generate in a fixed order. | **Best description of our classification control flow.** The application prepares the search and request; the model selects labels. The three explanatory stages below expand what happens between retrieval and generation. |
| Agentic RAG | The model chooses retrieval tools and follow-up searches. | Not implemented in this path. Coding agents helped build the app, but the running classifier has no model-directed search tools. |
| Adaptive RAG | Choose a retrieval strategy according to the input's complexity or need for evidence. | Not implemented. Budget controls and freshness/reanalysis rules decide whether work is admitted; they do not route a query among different retrieval strategies. |
| Hybrid RAG architecture | A broad label for combining fixed retrieval with additional checking or more flexible control. | We have local preparation and validation, but no autonomous retrieval loop. The precise “fixed sparse retrieval-augmented classification” description is less ambiguous. |
| RAG with memory | Add retained information that can influence later work. This describes an extra capability rather than one universally defined architecture. | We persist **application state**: profiles, taxonomy, decisions and receipts. There is no semantic search over chat histories or model memories in this path. |

The fixed/agentic/hybrid terminology follows [LangChain's architecture comparison](https://docs.langchain.com/oss/python/deepagents/retrieval). The complexity-based meaning of Adaptive-RAG comes from the [research paper](https://arxiv.org/abs/2403.14403). The mapping to our implementation is a code-based assessment, not a claim that these labels have one universal definition.

Research also uses **Naive, Advanced and Modular RAG**. Gao and colleagues describe a basic retrieve-read pipeline, improvements before/after retrieval, and more composable modules and flows. Our context selection and validation are explicit engineering improvements, but naming separate Python functions does not establish that we implement every method in an “Advanced” or “Modular” research architecture. [RAG survey, sections II-A–II-C](https://arxiv.org/html/2312.10997v5).

| Retrieval strategy | How it matches knowledge | Our current classification path |
|---|---|---|
| Sparse / lexical | Match words and weight their usefulness. | **Used:** IDF-weighted cosine over canonical label documents, plus the stored-name/alias bonus. |
| Dense / embedding | Compare learned representations that can capture semantic similarity. | Not used in this path. |
| Hybrid search | Combine lexical and dense retrieval signals. | Not used. Cosine plus an alias bonus still uses lexical evidence; it does not add an embedding retriever. |

Dense/sparse mixtures are a retrieval choice, distinct from a “hybrid RAG” control architecture. The [survey's mixed/hybrid retrieval discussion](https://arxiv.org/html/2312.10997v5) describes this distinction in retrieval techniques. Our code supports the lexical assessment above; it contains no embedding/vector-store or separate neural reranking step in this flow.

## Retrieval → Augment → Generate: our actual work

| Stage and purpose | Inputs | What happens locally or in the model | Output |
|---|---|---|---|
| **Retrieval — find possible existing labels** | All Evidence Parser records, including E0 and retained README passages; active canonical Project/Topic/Tag names, definitions and aliases. | Local binary-presence IDF cosine plus a once-per-label name/alias bonus ranks labels. Per-kind caps apply, then the application removes already handled or rejected choices. | Candidate IDs; the application expands surviving IDs into `id`, `kind`, `name`, `description` objects. It does not retrieve README chunks here. |
| **Augment — build the model's context** | Candidate objects plus the stored repository profile. | Local `compact()` keeps E0 and up to two early README fragments and up to eight RAKE phrase strings. The app adds source/workspace/revision/policy fields, the fixed classification system instruction and the strict answer schema. | Two model messages, system + JSON user, with a structured-output requirement. Local scores, aliases and full stored decision history are not candidate payload fields. |
| **Generate — select supported labels** | The bounded request assembled above. | The LLM is instructed to evaluate the supplied candidates against the supplied evidence and return a structured classification using existing IDs. It has no retrieval tools; local validation rejects invalid selections. | `status`, `summary`, and `assignments`; each assignment has `kind`, `concept_id`, `confidence`, `evidence_ids`, `reason`. Local validation and human review follow generation. |

For the existing authored **Orion API** example, E1 says: “Patient intake API for the Orion Clinical Platform. Uses FastAPI and Python.” Local retrieval therefore considers labels including **Orion Clinical Platform**, **Web APIs**, **fastapi**, and **python**. It also retrieves weaker lexical matches such as **Forge Build Platform** and **Package Management**. Retrieval supplies possibilities, not accepted truth.

Augmentation includes that short evidence and phrase strings such as `patient intake api`, beside candidate definitions. The `t-api` candidate becomes this actual object from the [saved documentation payload](classification-payload.json):

```json
{
  "id": "t-api",
  "kind": "TOPIC",
  "name": "Web APIs",
  "description": "HTTP services, ASGI and web frameworks"
}
```

The model can now judge the repository evidence against a defined, existing choice. A matching word or alias alone is insufficient: unsupported weak candidates should be rejected. This revision generates **no new classification result**; output cards in the illustration explain the expected structure. The full exact system instruction, JSON input and schema remain in the main walkthrough and its saved artifacts.

## Detailed boundaries behind the three stages

| Question | What the code does | Consequence |
|---|---|---|
| What acts as the search query? | All locally retained repository evidence, including E0 and selected README records. | Search can use more source evidence than the compact subset later sent to the model. RAKE phrases are not the search query. |
| What knowledge is retrieved? | Existing Project, Topic and Tag definitions: canonical name, description and aliases, searched locally. | The model chooses among existing IDs. Domains follow assigned Projects. |
| What is the retrieval algorithm? | Binary-presence, IDF-weighted cosine, configured as `tfidf`, with a once-per-label `+3` name/alias bonus and per-kind caps. | It is lexical retrieval. There are no dense embeddings or a separate neural reranker in this path. The bonus improves name matching but can also promote broad aliases. |
| What is augmentation? | Candidate `id`/`kind`/`name`/`description` objects are assembled with compact source evidence and RAKE phrase strings; fixed instructions and a strict answer schema bound the task. | The LLM sees a small, explicit set of choices rather than the full registry. Scores and aliases remain local. |
| What is generation? | One prepared classification request asks for supported canonical IDs, evidence citations and the other fields of the existing structured schema. | “Generation” produces structured selections, not a free-form article or a new vocabulary. One pass describes the retrieval plan; transport retries do not create an agentic search loop. |
| What happens after generation? | Local schema/ID/evidence checks and application rules gate reviewable suggestions. | A valid citation ID does not itself prove that the cited text supports the label. Human review and measured evaluation remain necessary. |
| What memory exists? | Local SQLite application state retains repository profiles, canonical taxonomy, decisions and analysis receipts. | The app can reuse work, respect decisions and avoid repeated analysis. It does not retrieve conversation history or send the entire saved state to the LLM. |
| Is taxonomy discovery this same RAG path? | No. Discovery sends a compact collection of repository profiles to propose vocabulary, without the Canonical Retriever. | The illustrated RAG path applies to model-assisted classification, not to every operation in the application. Local rules/reconciliation may also bypass generation. |

We should **not call the implementation agentic RAG**: the model does not choose retrieval tools or launch follow-up searches. Nor does adaptive budgeting establish the query-complexity routing described in **Adaptive-RAG**, whose paper selects among no-retrieval, single-step and iterative strategies. That router is absent here. [Adaptive-RAG paper](https://arxiv.org/abs/2403.14403).

“Memory” is a separate property from retrieval control. The precise wording above avoids implying a semantic memory system simply because the application persists state. Similarly, combining cosine scoring and an alias rule does not constitute dense-plus-sparse hybrid search.

## Code and evidence behind the picture

- [Evidence Parser, RAKE, compact selection and Retriever](../../../backend/app/pretest/ai/evidence.py): `selected_evidence()`, `profile()`, `compact()`, `Retriever.candidates()`.
- [Application orchestration](../../../backend/app/demo/service.py): the discovery branch returns before classification constructs `Retriever(..., method="tfidf")`; classification expands surviving candidate IDs into bounded request fields.
- [Provider](../../../backend/app/pretest/ai/provider.py): fixed system and JSON user messages, structured output and local validation; no model-selected retrieval tools.
- [Persistent application state](../../../backend/app/demo/store.py) and [analysis admission/receipts](../../../backend/app/demo/analysis.py): stored state and the “Already analyzed; reconcile offline” gate.
- [Exact authored example request](classification-payload.json), [registry](registry.json) and [ranking trace](retrieval.json). These are existing documentation examples, not new live evaluation results.
- [Exact illustration prompts](illustration-alias-readme-rag-2026-10-20-prompts.json). Built-in image generation; original pipeline figures and application algorithms are preserved.
- [Focused correction prompt](illustration-rag-review-correction.json) and [three-stage style revision](illustration-rag-review-v3.json). The first and v2 exports are retained; the selected review export is `rag-approach-review-v3.png`. The latter removes the furniture/plant and emphasizes Retrieval, Augment and Generate as requested.

## Proposed placement after approval

Add this illustration and a short explanation near the beginning of the pipeline walkthrough, after the taxonomy-versus-classification distinction. Keep the detailed parser, retrieval, prompt and payload sections intact. The new README banner is a separate, approved navigation graphic and does not embed this pending figure.
